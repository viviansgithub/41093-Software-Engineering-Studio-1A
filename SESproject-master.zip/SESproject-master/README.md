## Specific requirements/run the app
In order to copy the app code, use the following command in your chosen directory: "npx create-next-app -e https://github.com/tomi13909472/SESproject". This will initiate a next project with the appropriate dependencies and install all necessary modules. Now change into that directory and run the command "npm run server" and in another terminal window (in the same directory) run the command "npm run dev". Now the website is running on [http://localhost:3000](http://localhost:3000).

## To start github
Do the following commands in the project directory:
git remote add origin https://github.com/tomi13909472/SESproject
git branch --set-upstream-to=origin/master master
git pull --allow-unrelated-histories

The command should pull successfully and now git is ready.
